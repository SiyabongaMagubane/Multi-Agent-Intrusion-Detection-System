package classification;
import jade.core.Agent;
import jade.lang.acl.ACLMessage;


public class EnsembleAgent extends Agent {
	@Override
	protected void setup(){
		System.out.println(" Hello Ensemble Agent is ready " + getAID().getName() );
		ACLMessage msg = receive();
		
		if (msg != null){
			System.out.print(msg.getContent());
		}
		
	}

}
