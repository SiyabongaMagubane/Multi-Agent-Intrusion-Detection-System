package classification;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;;

public class ClassifyAgent extends Agent{
	
	public ClassifyAgent(){
		
	}
	
	@Override
	protected void setup(){
		System.out.println(" Hello classify Agent is ready " + getAID().getName() );
		/*ACLMessage msg = new ACLMessage(ACLMessage.PROPOSE);
		msg.addReceiver(new AID("EnsembleAgent", AID.ISLOCALNAME));
		msg.setLanguage("English");
		msg.setOntology("Todays-Game-forecast-ontology");
		msg.setContent("SpringBoks win");
		send(msg);
		*/
		addBehaviour( new ExecuteClassification());
	}
	
	private class ExecuteClassification extends CyclicBehaviour {
		
		public void action(){
			System.out.println("Inside the executeClassification");
			if (myAgent.receive() != null){
			ACLMessage msg = myAgent.receive();
			System.out.println("Receieved msg sent ");
			
			if ( msg!= null){
				System.out.println("Received classification request: " + msg.getContent());
				ACLMessage reply = msg.createReply();
				KNearest classification = new KNearest();
				try {
					classification.LoadData("/Users/siyabonga/Documents/workspace/Classification/src/classification/KDDTrain.csv");
					System.out.println("Loading data");
					classification.FeatureExtractionTraining();
					classification.FeatureExtractionTest();
					classification.KNN();
					reply.setPerformative(ACLMessage.ACCEPT_PROPOSAL);
					reply.setContent(classification.ClassificationResultTrueValues().toString() + "," + classification.ClassificationResultPredictions().toString());	
					myAgent.send(reply);
				}
				catch ( Exception e) {
					reply.setPerformative(ACLMessage.REFUSE);
					block();
					System.out.println(e);
				}	
			
			}
		}
			else {
				block();
			}
			
	}
		
		protected void takeDown(){
			System.out.println("Classifying agent" +getAID().getName() + " terminating");
		}
	}

}
