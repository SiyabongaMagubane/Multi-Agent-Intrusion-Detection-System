package classification;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class CommunicationAgent extends Agent  {
	int classes;
	private JTextField numberOfClasses;
	private JFrame frame;
    private JPanel pane;
	
	@Override
	protected void setup(){
		System.out.println(" Hello Communication Agent is ready " + getAID().getName() );
		addBehaviour( new ReadInput());
		//addBehaviour( new ReceiveClassResults());
		
	}
	
	// read number of agents and invoke their classification by sending message to classify
private class ReadInput extends OneShotBehaviour{
	// The list of known seller agents
	private Vector classifyAgents = new Vector();
		public void action(){
		pane = new JPanel();
        pane.setLayout(new GridLayout(0, 2, 2, 2));

        numberOfClasses = new JTextField(5);


        pane.add(new JLabel("Enter the number of classes"));
        numberOfClasses.setBounds(20, 30, 20, 30); 
        pane.add(numberOfClasses);
        
        int option = JOptionPane.showConfirmDialog(frame, pane, "Please fill all the fields", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

        if (option == JOptionPane.YES_OPTION) {

            try {
            	classes  = Integer.parseInt(numberOfClasses.getText());
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace();
            }
            
        }
        
    	//System.out.println("Sending out the comms");
		for ( int i = 0; i < classes ; i++){
			AID classifyAgent = new AID((String) ("ClassifyAgent" +Integer.toString(i)), AID.ISLOCALNAME);
			classifyAgents.addElement(classifyAgent);	
			System.out.println("Agent:"+classifyAgent.getName());
			ACLMessage msg = new ACLMessage(ACLMessage.CFP);
	        msg.addReceiver(classifyAgent);
	        msg.setContent("ClassifyAgent"+(i+1));
	        System.out.println("Sending classification request: " + msg.getContent());
	        myAgent.send(msg);
		}
 
	   }

	}
	
	//Receive the classification results and send to ensemble agent
	/*private class ReceiveClassResults extends CyclicBehaviour {
		public void action(){
			ACLMessage msg = myAgent.receive();
			System.out.println("Sending classification request: " + msg.getContent());
			if ( msg!= null){
				
			
			}
			else {
				block();
			}
		addBehaviour( new Ensemble());
		}
		
	}*/
	//send message to ensemble method with classification results from ClassifyAgent
	/*private class Ensemble extends CyclicBehaviour {
		public void action(){
		
		}
		
	}
	
	*/

	
	
}
