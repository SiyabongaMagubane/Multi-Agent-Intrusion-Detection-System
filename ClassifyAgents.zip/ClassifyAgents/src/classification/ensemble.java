package classification;

public interface ensemble {

	void ensemble();

	void addBase();

	void removeBase();

	void RoundsOfBagging(); // rounds how many rounds of bagging to perform.

	void voting();

}
