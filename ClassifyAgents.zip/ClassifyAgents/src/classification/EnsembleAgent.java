package classification;

import java.util.ArrayList;
import java.util.HashMap;

import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.*;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.MessageTemplate;;

public class EnsembleAgent extends Agent {
	@Override
	protected void setup() {
		System.out.println(" Hello Ensemble Agent is ready " + getAID().getName());
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		ServiceDescription sd = new ServiceDescription();
		sd.setType("ensemble");
		sd.setName("Ensemble");
		dfd.addServices(sd);
		try {
			DFService.register(this, dfd);
		}
		catch (FIPAException fe) {
			fe.printStackTrace();
		}
		addBehaviour( new EnsembleMethod());

	}
	protected void takeDown() {
		// Deregister from the yellow pages
		try {
			DFService.deregister(this);
		}
		catch (FIPAException fe) {
			fe.printStackTrace();
		}
		// Printout a dismissal message
		System.out.println("Ensemble-agent "+getAID().getName()+" terminating.");
	}
	private class EnsembleMethod extends CyclicBehaviour {
		private String response;
		private String [] responseClassification ;
		private ArrayList<String> responsePerAgent;
		private String [] Temporary;
		private ArrayList<ArrayList<String>> TrueValues;
		private ArrayList<ArrayList<String>> PredictionValues;
		
		@Override
		public void action() {
			// TODO Auto-generated method stub
			TrueValues = new ArrayList<ArrayList<String>>();
			MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL);
			ACLMessage msg = myAgent.receive(mt);
			if (msg != null) {
				// ACCEPT_PROPOSAL Message received. Process it
				String predictions = msg.getContent();
				ACLMessage reply = msg.createReply();
				System.out.println(" received the ensemble input now about to write the ensemble method");
				response = reply.getContent();
				responseClassification = response.split("-");
				String perAgent = "";
				int counter = 0;
				for ( int i = 0 ; i < responseClassification.length; i++){
					//System.out.println(" Content index: "+ (i+1)+" : " +responseClassification[i]);
					String [] temp = responseClassification[i].trim().split("]");
					for (int p = 0; p < temp.length ; p++){
						responsePerAgent.set(p, temp[p]);
					}
					
					for ( int k = 0; k < responsePerAgent.size() ; k++){
						//System.out.println("Index " + (k+1)+" : " +temp[k]);
						Temporary = responsePerAgent.get(k).trim().split(",") ;
						for ( int x = 0; x < Temporary.length ; x++){
							
						}
						if (counter %  2 == 0){
							
						TrueValues.get(i).set(i,Temporary);
						
						}
					}
				}
				reply.setPerformative(ACLMessage.INFORM);
				reply.setContent("Received the ensemble request");
				myAgent.send(reply);
			}
			else {
				block();
			}
			
		}
		
	}

}
